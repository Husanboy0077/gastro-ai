# Gastro-AI

> A deep learning model for diagnosing gastrointestinal diseases from endoscopic images using the HyperKvasir dataset.

## 📌 About the Project

Gastro-AI is a CNN-based classification model (ResNet-50) trained on the HyperKvasir dataset to identify gastrointestinal conditions like polyps, cancer, inflammation, and ulcers. It processes an image in **0.18 seconds** and reaches **90.7% accuracy**.

## 🚀 Features

- Trained on 10,662 labeled images (23 classes)
- Built using ResNet-50 with transfer learning
- Real-time image inference (0.18s per image)
- Achieved 0.93 AUC on test data

## 📁 Project Structure

```
gastro-ai/
├── train.py
├── inference.py
├── requirements.txt
├── model/
├── data/
└── notebooks/
```

## 🧪 Dataset

Dataset used: [HyperKvasir (Official)](https://datasets.simula.no/hyper-kvasir/)

## 💾 Model Weights

📥 [Download Model Weights (Google Drive)](https://drive.google.com/file/d/abc123xyz/view)

## 📦 Installation

```bash
git clone https://github.com/username/gastro-ai.git
cd gastro-ai
pip install -r requirements.txt
```

## ▶️ Inference Example

```bash
python inference.py --image data/sample_images/test1.jpg
```

## 📜 License

This project is licensed under the MIT License.
